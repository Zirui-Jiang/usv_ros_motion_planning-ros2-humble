"""ROS-independent planning worker and navigation freshness rules."""
from dataclasses import dataclass, field, replace
import math
import time
import numpy as np

from common.models import AlgorithmStatus, GridSnapshot, USVModel, VesselState
from common.collision import footprint_path_is_clear
from path_planner.path_planner_core import PathPlannerCore, path_is_clear_with_inflation_escape
from trajectory_planner.trajectory import Trajectory
from trajectory_planner.trajectory_planner_factory import create_trajectory_planner
from .configuration import C, T, section


def fresh(stamp, now, timeout):
    """Future data is invalid too (clock rewind or mismatched clock domain)."""
    return all(math.isfinite(v) for v in (stamp, now, timeout)) and -1e-6 <= now - stamp <= timeout


def readiness(now, state, grid, trajectory, config):
    if state is None or not fresh(state.stamp, now, config['navigation.state_timeout']):
        return 'WAITING_STATE'
    if grid is None or not fresh(grid.stamp, now, config['navigation.map_timeout']):
        return 'WAITING_MAP'
    if state.frame_id != grid.frame_id:
        return 'FRAME_MISMATCH'
    if trajectory is None or trajectory.empty() or not fresh(
            trajectory.stamp, now, config['navigation.trajectory_timeout']):
        return 'WAITING_REFERENCE'
    if trajectory.frame_id != state.frame_id:
        return 'FRAME_MISMATCH'
    return 'NAVIGATING'


@dataclass(frozen=True)
class PlanningRequest:
    version: int
    goal: tuple
    state: VesselState
    grid: GridSnapshot
    route: np.ndarray
    parameters: dict
    mission_intent: object = None


@dataclass(frozen=True)
class PlanningResponse:
    version: int
    status: AlgorithmStatus
    route: np.ndarray
    trajectory: Trajectory
    elapsed: float
    message: str = ''
    searched: bool = False
    expanded: int = 0
    selected_goal: tuple | None = None
    metadata: dict = field(default_factory=dict)


def plan_navigation(request):
    """Runs in one spawned process; consumes only immutable/copy snapshots."""
    if request.mission_intent is not None:
        from .missions.planning import plan_mission
        return plan_mission(request)
    begun = time.perf_counter()
    cfg = request.parameters
    route = np.empty((0, 3))
    searched, expanded = False, 0

    def result(status, trajectory=None, message=''):
        return PlanningResponse(request.version, status, route,
                                trajectory if trajectory is not None else Trajectory(),
                                time.perf_counter() - begun, message, searched, expanded)

    try:
        if request.state.frame_id != request.grid.frame_id:
            return result(AlgorithmStatus.INVALID_INPUT, message='state/map frame mismatch')
        planner_cfg = section(cfg, 'path_planner.')
        planner_cfg.update(planner_name=cfg['planner_name'], obstacle_factor=cfg['obstacle_factor'],
                           timeout=cfg['navigation.planning_timeout'],
                           max_expansions=cfg['navigation.max_expansions'])
        planner = PathPlannerCore(planner_cfg)
        route = planner.prune(request.route, request.state)
        threshold = 254.0 * cfg['obstacle_factor']
        # Check the vessel-to-route connection and remaining segments on the
        # latest map with the same policy that accepted the global route.
        # A legal soft descent must not become a false invalidation merely
        # because the vessel is still in its original inflated start region.
        connected = np.vstack((request.state.pose, route)) if len(route) else route
        if not len(route) or not path_is_clear_with_inflation_escape(
                request.grid, connected, threshold, planner.planner.unknown_is_obstacle,
                outline_map=planner.planner.outline_map,
                allow_corner_cutting=planner.planner.allow_corner_cutting):
            searched = True
            found = planner.make_plan(request.state.pose, request.goal, request.grid)
            expanded = found.expanded
            route = found.path
            if not found.success:
                return result(found.status, message=found.message)
        model = USVModel.from_mapping(section(cfg, 'dynamics.'))
        los_config = section(cfg, T + 'los.')
        controller_tolerance = cfg[C + cfg[C + 'controller_name'] + '_controller.goal_distance_tolerance']
        endpoint_offset = float(np.linalg.norm(route[-1, :2] - request.goal[:2]))
        if endpoint_offset < controller_tolerance:
            # Preserve the grid endpoint and its final approach direction.
            # By the triangle inequality, this LOS stop disk lies entirely
            # within the controller's disk around the actual requested goal.
            los_config['goal_tolerance'] = min(
                los_config['goal_tolerance'], controller_tolerance - endpoint_offset)
        else:
            # A centre outside/on the actual-goal disk cannot support a
            # positive LOS stop radius. Keep it and validate a new connection.
            connection = np.vstack((route[-1], request.goal))
            if not path_is_clear_with_inflation_escape(
                    request.grid, connection, threshold, planner.planner.unknown_is_obstacle,
                    outline_map=planner.planner.outline_map,
                    allow_corner_cutting=planner.planner.allow_corner_cutting):
                return result(AlgorithmStatus.NO_PATH, message='goal connection failed grid collision validation')
            route = np.vstack((route, request.goal))
            los_config['goal_tolerance'] = min(los_config['goal_tolerance'], controller_tolerance)
        guidance = create_trajectory_planner(cfg[T + 'planner_name'], model, los_config)
        generated = guidance.plan(route, request.state)
        if generated.status not in (AlgorithmStatus.SUCCESS, AlgorithmStatus.GOAL_REACHED):
            return result(generated.status, message=generated.message)
        trajectory = generated.trajectory
        # The exact requested goal, not a grid-cell centre, defines completion.
        trajectory.goal = tuple(request.goal[:2])
        # A* retains its original soft-cost threshold. Local collision safety
        # checks the complete hull against lethal/unknown cell areas instead:
        # rejecting the centre at every soft inflated cost can deadlock a
        # physically clear turn, while centre-only checks miss bow collisions.
        if not footprint_path_is_clear(request.grid, trajectory.points[:, [2, 3, 4]],
                                       cfg['navigation.footprint_length'], cfg['navigation.footprint_width']):
            return result(AlgorithmStatus.NO_PATH, message='LOS swept footprint intersects lethal or unknown map cells')
        return result(generated.status, trajectory)
    except (ValueError, TypeError, ArithmeticError) as error:
        return result(AlgorithmStatus.INVALID_INPUT, message=str(error))


class LatestPlanWorker:
    """One executing job and one replaceable pending snapshot, no unbounded queue."""
    def __init__(self, executor=None):
        if executor is None:
            import multiprocessing
            from concurrent.futures import ProcessPoolExecutor
            executor = ProcessPoolExecutor(1, mp_context=multiprocessing.get_context('spawn'))
        self.executor = executor
        self.future = None
        self.pending = None
        self.replaced = 0

    def offer(self, request):
        if self.pending is not None:
            self.replaced += 1
        self.pending = request
        self._start()

    def _start(self):
        if self.future is None and self.pending is not None:
            request, self.pending = self.pending, None
            self.future = self.executor.submit(plan_navigation, request)

    def poll(self):
        if self.future is None or not self.future.done():
            return None
        future, self.future = self.future, None
        try:
            result = future.result()
            # A request queued while the first global search is running still
            # contains an empty route. Carry the completed route into that
            # request before dispatch, otherwise process startup causes a
            # second search from a different cell as soon as the boat moves.
            # Keep the latest state, map and parameters: plan_navigation will
            # revalidate this route against that map before reusing it.
            if (self.pending is not None and self.pending.version == result.version
                    and result.status in (AlgorithmStatus.SUCCESS, AlgorithmStatus.GOAL_REACHED)
                    and (self.pending.mission_intent is None
                         or self.pending.mission_intent.kind != 'circle')):
                self.pending = replace(self.pending, route=result.route.copy())
            return result
        finally:
            self._start()

    def invalidate(self):
        self.pending = None
        if self.future is not None and self.future.cancel():
            self.future = None

    def close(self):
        self.invalidate()
        self.executor.shutdown(wait=True, cancel_futures=True)
