#!/usr/bin/env bash
set -euo pipefail
# A new, owned Linux workspace; never overwrite the previously accepted build.
source_repo="$(realpath "$1")"
mission_ws="$2"
if [[ -e "$mission_ws" ]]; then
  echo "Refusing existing output: $mission_ws" >&2
  exit 2
fi
git clone --no-hardlinks "$source_repo" "$mission_ws"
rsync -a --exclude=.git --exclude=__pycache__ --exclude=.pytest_cache \
  --exclude=build --exclude=install --exclude=log "$source_repo/" "$mission_ws/"
mkdir -p "$mission_ws/validation"
git -C "$source_repo" rev-parse HEAD > "$mission_ws/validation/base-commit.txt"
git -C "$source_repo" diff --binary > "$mission_ws/validation/source.patch"
git -C "$source_repo" status --porcelain=v1 > "$mission_ws/validation/source-status.txt"
cd "$mission_ws"
set +u
source /opt/ros/humble/setup.bash
set -u
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
colcon build --parallel-workers 3 --cmake-args -DCMAKE_BUILD_TYPE=Release \
  > validation/build.log 2>&1
set +u
source install/setup.bash
set -u
python3 scripts/validation/verify_install.py --source "$mission_ws" --install "$mission_ws/install" \
  --output "$mission_ws/validation/install-audit.json"
bash scripts/validation/run_source_tests.bash > validation/source-tests.log 2>&1
cat validation/source-tests.log
