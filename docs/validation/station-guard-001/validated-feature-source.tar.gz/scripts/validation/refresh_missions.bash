#!/usr/bin/env bash
set -euo pipefail
source_repo="$(realpath "$1")"
mission_ws="$(realpath "$2")"
test -f "$mission_ws/validation/base-commit.txt"
test "$mission_ws" != "$source_repo"
run_dir="$(mktemp -d "$mission_ws/validation/refresh-XXXXXX")"
echo "Refresh evidence: $run_dir"
rsync -a --exclude=__pycache__ --exclude=.pytest_cache "$source_repo/src/" "$mission_ws/src/"
rsync -a --exclude=__pycache__ "$source_repo/scripts/" "$mission_ws/scripts/"
cp "$source_repo/conftest.py" "$mission_ws/conftest.py"
git -C "$source_repo" diff --binary > "$run_dir/source.patch"
git -C "$source_repo" status --porcelain=v1 > "$run_dir/source-status.txt"
cd "$mission_ws"
set +u
source /opt/ros/humble/setup.bash
set -u
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
colcon build --packages-select common controller trajectory_planner sim_env \
  --parallel-workers 3 --cmake-args -DCMAKE_BUILD_TYPE=Release > "$run_dir/build.log" 2>&1
set +u
source install/setup.bash
set -u
python3 scripts/validation/verify_install.py --source "$mission_ws" --install "$mission_ws/install" \
  --output "$run_dir/install-audit.json"
test_exit=0
bash scripts/validation/run_source_tests.bash > "$run_dir/source-tests.log" 2>&1 || test_exit=$?
cat "$run_dir/source-tests.log"
exit "$test_exit"
