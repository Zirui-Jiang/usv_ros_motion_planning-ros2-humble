#!/usr/bin/env bash
set -euo pipefail
mission_ws="$(realpath "$1")"
shift
set +u
source /opt/ros/humble/setup.bash
source "$mission_ws/install/setup.bash"
set -u
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 ROS_LOCALHOST_ONLY=1
exec python3 "$mission_ws/scripts/validation/mission_matrix.py" --workspace "$mission_ws" "$@"
